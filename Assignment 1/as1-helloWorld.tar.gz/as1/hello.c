#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#define MAX_TURNS 8
#define NUM_OF_WRONG_FLASH 5
#define DIRECTIONS 4
#define NUM_LEDS 4

static char LED0_BRIGHTNESS[] = "/sys/class/leds/beaglebone:green:usr0/brightness";
static char LED1_BRIGHTNESS[] ="/sys/class/leds/beaglebone:green:usr1/brightness";
static char LED2_BRIGHTNESS[] ="/sys/class/leds/beaglebone:green:usr2/brightness";
static char LED3_BRIGHTNESS[] ="/sys/class/leds/beaglebone:green:usr3/brightness";
static char LED0[] = "/sys/class/leds/beaglebone:green:usr0/trigger";
static char LED1[] = "/sys/class/leds/beaglebone:green:usr1/trigger";
static char LED2[] = "/sys/class/leds/beaglebone:green:usr2/trigger";
static char LED3[] = "/sys/class/leds/beaglebone:green:usr3/trigger";
static char JS_UP[] = "/sys/class/gpio/gpio26/value";
static char JS_DOWN[] = "/sys/class/gpio/gpio46/value";
static char JS_LEFT[] = "/sys/class/gpio/gpio65/value";
static char JS_RIGHT[] = "/sys/class/gpio/gpio47/value";

enum joystick {UP, DOWN, LEFT, RIGHT, CENTER};
enum joystick direction = CENTER;

static bool IS_LED0_ON = false;
static bool IS_LED3_ON = false;

int findDirection();
void waitJoystickDirection();
void waitJoystickRelease();
void sleepProcess(long seconds, long nanoseconds);
void checkAnswer();
void randomLED();
void controlLED(int led, char *mode);
void controlAllLED(int num_of_leds, char *_all_leds[], char *mode);
void disableLEDs();
void quitApplication();
void flashLEDs(char *answer);

static bool init = true;
static int score = 0;

int main(int argc, char **argv) {
    printf("Hello Embedded World, from Kidjou Chang!\n");
    printf("Press the Zen cape's Joystick in the direction of the LED.\n");
    printf("UP for LED 0 (top)\nDOWN for LED 3 (bottom)\nLEFT/RIGHT for exit app.\n");
    
    disableLEDs();
    int turn = 0;
    init = false;

    while (turn < MAX_TURNS) {
        randomLED();
        printf("Press joystick; current score (%d / %d)\n", score, turn);
        waitJoystickDirection();
        if (direction == UP || direction == DOWN) {
            checkAnswer();
        }
        else if (direction == LEFT || direction == RIGHT) {
            quitApplication();
            printf("Exiting app!\n");
            exit(1);
        }
        waitJoystickRelease();
        turn++;
    }

    printf("Your final score was (%d / %d)\n", score, turn);
    printf("Thank you for playing!\n");
    quitApplication();

    return 0;
}

// Function to check if answer is correct
void checkAnswer() {
    char *answer = NULL;
    if ((direction == UP && IS_LED0_ON) || (direction == DOWN && IS_LED3_ON)) {
        score++;
        answer = "Correct";
        flashLEDs(answer);
        printf("%s!\n", answer);
    }
    else {
        answer = "Incorrect";
        flashLEDs(answer);
        printf("%s! :(\n", answer);
    }
}

// Function to flash all LEDs
void flashLEDs(char *answer) {
    const int NUM_OF_LEDS = NUM_LEDS;
    char *mode = NULL;
    char *_all_leds[NUM_OF_LEDS];
    _all_leds[0] = LED0_BRIGHTNESS;
    _all_leds[1] = LED1_BRIGHTNESS;
    _all_leds[2] = LED2_BRIGHTNESS;
    _all_leds[3] = LED3_BRIGHTNESS;

    if (strcmp(answer, "Correct") == 0) {
        mode = "1";
        controlAllLED(NUM_OF_LEDS, _all_leds, mode);
        sleepProcess(0, 100000000);
        mode = "0";
        controlAllLED(NUM_OF_LEDS, _all_leds, mode);
        sleepProcess(0, 100000000);
    }
    else {
        for (int i = 0 ; i < NUM_OF_WRONG_FLASH; i++) {
            mode = "1";
            controlAllLED(NUM_OF_LEDS, _all_leds, mode);
            sleepProcess(0, 100000000);
            mode = "0";
            controlAllLED(NUM_OF_LEDS, _all_leds, mode);
            sleepProcess(0, 100000000);
        }
    }
}

// Function that control all LEDs
void controlAllLED(int num_of_leds, char *_all_leds[], char *mode) {
    for (int i = 0; i < num_of_leds; i++) {
        FILE *_file = fopen(_all_leds[i], "w");
        // Check if file is open
        if (_file == NULL) {
            printf("Unable to open file (%s) for write\n", _all_leds[i]);
            exit(1);
        }
        // Write file
        int charWritten = fprintf(_file, "%s", mode);
        if (charWritten <= 0) {
            printf("Error writing data\n");
            exit(1);
        }
        fclose(_file);
    }
}

// Function to close and quit application
void quitApplication() {
    char *mode = "0";
    if (IS_LED0_ON) {
        int _led_0 = 0;
        controlLED(_led_0, mode);
        IS_LED0_ON = false;
    }
    if (IS_LED3_ON) {
        int _led_3 = 3;
        controlLED(_led_3, mode);
        IS_LED3_ON = false;
    }
}

// Function to turn off all LEDs
void disableLEDs() {
    const int NUM_OF_LEDS = NUM_LEDS;
    char *_all_leds[NUM_OF_LEDS];
    _all_leds[0] = LED0;
    _all_leds[1] = LED1;
    _all_leds[2] = LED2;
    _all_leds[3] = LED3;

    // Turn off all LEDS at first
    for (int i = 0; i < NUM_OF_LEDS; i++) {
        FILE *_file = fopen(_all_leds[i], "w");
        // Check if file is open
        if (_file == NULL) {
            printf("Unable to open file (%s) for write\n", _all_leds[i]);
            exit(1);
        }
        // Write file
        int charWritten = fprintf(_file, "none");
        if (charWritten <= 0) {
            printf("Error writing data\n");
            exit(1);
        }
        fclose(_file);
    }
}

// Function to randomly select LED0/LED3 to turn on/off
void randomLED() {

    if (!init) {
        char *mode_off = "0";
        if (IS_LED0_ON) {
            int _led_0 = 0;
            controlLED(_led_0, mode_off);
            IS_LED0_ON = false;
        }
        else if (IS_LED3_ON) {
            int _led_3 = 3;
            controlLED(_led_3, mode_off);
            IS_LED3_ON = false;
        }
    }
    int random_led = rand() % 21 <= 10 ? 0 : 3;
    char *mode_on = "1"; 
    if (random_led == 0) {
        IS_LED0_ON = true;
    }
    else {
        IS_LED3_ON = true;
    }
    controlLED(random_led, mode_on);
}

// Function to control state of LED on/off
void controlLED(int led, char *mode) {
    FILE *_file = NULL;
    if (led == 0) {
        _file = fopen(LED0_BRIGHTNESS, "w");
    }
    else {
        _file = fopen(LED3_BRIGHTNESS, "w");
    }
    if (_file == NULL) {
        printf("Unable to open file for write\n");
        exit(1);
    }
    int charWritten = fprintf(_file, "%s", mode);
    if (charWritten <= 0) {
        printf("Error writing data\n");
        exit(1);
    }
    fclose(_file);
}

// Function to wait joystick input direction
void waitJoystickDirection() {
    while (direction == CENTER) {
        int result = findDirection();
        if (result == UP) {
            direction = UP;
        }
        else if (result == DOWN) {
            direction = DOWN;
        }
        else if (result == LEFT) {
            direction = LEFT;
        }
        else if (result == RIGHT) {
            direction = RIGHT;
        }
        sleepProcess(0, 100000000);
    }
}

// Function to wait joystick release
void waitJoystickRelease() {
    while (direction != CENTER) {
        int result = findDirection();
        if (result == CENTER) {
            direction = CENTER;
        }
        sleepProcess(0, 100000000);
    }
}

void sleepProcess(long seconds, long nanoseconds) {
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

// Function to capture joystick direction from GPIO
int findDirection() {
    bool input = false;
    int index = CENTER;
    const int NUM_DIRECTIONS = DIRECTIONS;
    char *_joystick_directions[NUM_DIRECTIONS];
    _joystick_directions[0] = JS_UP;
    _joystick_directions[1] = JS_DOWN;
    _joystick_directions[2] = JS_LEFT;
    _joystick_directions[3] = JS_RIGHT;

    // UP, DOWN, LEFT, RIGHT, CENTER
    for (int i = 0; i < NUM_DIRECTIONS; i++) {
        FILE *_file = fopen(_joystick_directions[i], "r");
        // Check if file is open
        if (_file == NULL) {
            printf("Unable to open file (%s) for read\n", _joystick_directions[i]);
            exit(1);
        }
        //Read file
        const int MAX_LENGTH = 1024;
        char buff[MAX_LENGTH];
        fgets(buff, MAX_LENGTH, _file);
        if (buff[0] == '0') {
            input = true;
            index = i;
        }
        fclose(_file);
        if (input) {
            break;
        }
    }
    return index;
}
